package com.menucontrol.app.adapters;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.menucontrol.app.R;
import com.menucontrol.app.models.Dish;

import java.util.List;
import java.util.Locale;

public class DishAdapter extends RecyclerView.Adapter<DishAdapter.DishViewHolder> {
    private List<Dish> dishes;
    private OnDishCountChangeListener listener;
    
    public interface OnDishCountChangeListener {
        void onIncrement(Dish dish);
        void onDecrement(Dish dish);
    }
    
    public DishAdapter(List<Dish> dishes, OnDishCountChangeListener listener) {
        this.dishes = dishes;
        this.listener = listener;
    }
    
    @NonNull
    @Override
    public DishViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_dish, parent, false);
        return new DishViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull DishViewHolder holder, int position) {
        Dish dish = dishes.get(position);
        holder.bind(dish);
    }
    
    @Override
    public int getItemCount() {
        return dishes.size();
    }
    
    public void updateDishes(List<Dish> newDishes) {
        this.dishes = newDishes;
        notifyDataSetChanged();
    }
    
    class DishViewHolder extends RecyclerView.ViewHolder {
        private TextView dishNameText;
        private TextView categoryText;
        private TextView priceText;
        private TextView revenueText;
        private TextView counterText;
        private MaterialButton plusButton;
        private MaterialButton minusButton;
        private View categoryIndicator;
        
        public DishViewHolder(@NonNull View itemView) {
            super(itemView);
            dishNameText = itemView.findViewById(R.id.dishNameText);
            categoryText = itemView.findViewById(R.id.categoryText);
            priceText = itemView.findViewById(R.id.priceText);
            revenueText = itemView.findViewById(R.id.revenueText);
            counterText = itemView.findViewById(R.id.counterText);
            plusButton = itemView.findViewById(R.id.plusButton);
            minusButton = itemView.findViewById(R.id.minusButton);
            categoryIndicator = itemView.findViewById(R.id.categoryIndicator);
        }
        
        public void bind(Dish dish) {
            dishNameText.setText(dish.getName());
            categoryText.setText(dish.getCategory());
            priceText.setText(String.format(Locale.getDefault(), "$%.2f", dish.getPrice()));
            counterText.setText(String.valueOf(dish.getDailyCount()));
            
            double revenue = dish.getDailyRevenue();
            revenueText.setText(String.format(Locale.getDefault(), "Ingresos: $%.2f", revenue));
            
            // Set category indicator color
            int categoryColor = getCategoryColor(dish.getCategory());
            categoryIndicator.setBackgroundTintList(ColorStateList.valueOf(categoryColor));
            
            // Enable/disable minus button based on count
            minusButton.setEnabled(dish.getDailyCount() > 0);
            minusButton.setAlpha(dish.getDailyCount() > 0 ? 1.0f : 0.5f);
            
            // Set click listeners
            plusButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onIncrement(dish);
                }
            });
            
            minusButton.setOnClickListener(v -> {
                if (listener != null && dish.getDailyCount() > 0) {
                    listener.onDecrement(dish);
                }
            });
        }
        
        private int getCategoryColor(String category) {
            switch (category) {
                case "Entradas":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_entradas);
                case "Platos Principales":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_principales);
                case "Postres":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_postres);
                case "Bebidas":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_bebidas);
                default:
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_otros);
            }
        }
    }
}