package com.menucontrol.app;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.menucontrol.app.dao.MenuDAO;
import com.menucontrol.app.models.DailyCount;

import java.text.SimpleDateFormat;
import java.util.*;

public class StatisticsActivity extends AppCompatActivity {
    private PieChart pieChart;
    private BarChart barChart;
    private TextView totalSalesText;
    private TextView totalRevenueText;
    private TextView topDishText;
    
    private MenuDAO menuDAO;
    private SimpleDateFormat dateFormat;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        
        initializeViews();
        initializeData();
        loadStatistics();
    }
    
    private void initializeViews() {
        pieChart = findViewById(R.id.pieChart);
        barChart = findViewById(R.id.barChart);
        totalSalesText = findViewById(R.id.totalSalesText);
        totalRevenueText = findViewById(R.id.totalRevenueText);
        topDishText = findViewById(R.id.topDishText);
    }
    
    private void initializeData() {
        menuDAO = new MenuDAO(this);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    }
    
    private void loadStatistics() {
        // Get last 30 days data
        Calendar endDate = Calendar.getInstance();
        Calendar startDate = Calendar.getInstance();
        startDate.add(Calendar.DAY_OF_MONTH, -30);
        
        String startDateStr = dateFormat.format(startDate.getTime());
        String endDateStr = dateFormat.format(endDate.getTime());
        
        List<DailyCount> historyData = menuDAO.getHistoryByDateRange(startDateStr, endDateStr);
        
        updateSummaryStats(historyData);
        setupPieChart(historyData);
        setupBarChart(historyData);
    }
    
    private void updateSummaryStats(List<DailyCount> historyData) {
        int totalSales = 0;
        double totalRevenue = 0.0;
        Map<String, Integer> dishCounts = new HashMap<>();
        
        for (DailyCount item : historyData) {
            totalSales += item.getQuantity();
            totalRevenue += item.getRevenue();
            
            String dishName = item.getDishName();
            dishCounts.put(dishName, dishCounts.getOrDefault(dishName, 0) + item.getQuantity());
        }
        
        totalSalesText.setText(String.valueOf(totalSales));
        totalRevenueText.setText(String.format(Locale.getDefault(), "$%.2f", totalRevenue));
        
        // Find top dish
        String topDish = "N/A";
        int maxCount = 0;
        for (Map.Entry<String, Integer> entry : dishCounts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                topDish = entry.getKey();
            }
        }
        topDishText.setText(topDish + " (" + maxCount + ")");
    }
    
    private void setupPieChart(List<DailyCount> historyData) {
        Map<String, Double> dishRevenues = new HashMap<>();
        
        for (DailyCount item : historyData) {
            String dishName = item.getDishName();
            dishRevenues.put(dishName, dishRevenues.getOrDefault(dishName, 0.0) + item.getRevenue());
        }
        
        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Double> entry : dishRevenues.entrySet()) {
            entries.add(new PieEntry(entry.getValue().floatValue(), entry.getKey()));
        }
        
        PieDataSet dataSet = new PieDataSet(entries, "Ingresos por Plato");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);
        
        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        
        Description desc = new Description();
        desc.setText("Distribución de Ingresos");
        pieChart.setDescription(desc);
        
        pieChart.setUsePercentValues(true);
        pieChart.setEntryLabelTextSize(10f);
        pieChart.setEntryLabelColor(Color.BLACK);
        
        pieChart.invalidate();
    }
    
    private void setupBarChart(List<DailyCount> historyData) {
        Map<String, Integer> dailySales = new TreeMap<>();
        
        for (DailyCount item : historyData) {
            String date = item.getDate();
            dailySales.put(date, dailySales.getOrDefault(date, 0) + item.getQuantity());
        }
        
        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;
        
        for (Map.Entry<String, Integer> entry : dailySales.entrySet()) {
            entries.add(new BarEntry(index, entry.getValue()));
            labels.add(entry.getKey().substring(5)); // Show MM-dd only
            index++;
        }
        
        BarDataSet dataSet = new BarDataSet(entries, "Ventas Diarias");
        dataSet.setColor(getResources().getColor(R.color.primary));
        dataSet.setValueTextSize(10f);
        
        BarData data = new BarData(dataSet);
        data.setBarWidth(0.9f);
        
        barChart.setData(data);
        
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        
        Description desc = new Description();
        desc.setText("Ventas por Día");
        barChart.setDescription(desc);
        
        barChart.setFitBars(true);
        barChart.invalidate();
    }
}