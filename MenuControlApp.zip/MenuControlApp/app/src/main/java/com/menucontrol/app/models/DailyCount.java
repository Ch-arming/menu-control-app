package com.menucontrol.app.models;

import java.io.Serializable;

public class DailyCount implements Serializable {
    private int id;
    private int dishId;
    private String date;
    private int quantity;
    private String dishName;
    private double dishPrice;
    
    public DailyCount() {}
    
    public DailyCount(int dishId, String date, int quantity) {
        this.dishId = dishId;
        this.date = date;
        this.quantity = quantity;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getDishId() {
        return dishId;
    }
    
    public void setDishId(int dishId) {
        this.dishId = dishId;
    }
    
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public String getDishName() {
        return dishName;
    }
    
    public void setDishName(String dishName) {
        this.dishName = dishName;
    }
    
    public double getDishPrice() {
        return dishPrice;
    }
    
    public void setDishPrice(double dishPrice) {
        this.dishPrice = dishPrice;
    }
    
    public double getRevenue() {
        return quantity * dishPrice;
    }
}