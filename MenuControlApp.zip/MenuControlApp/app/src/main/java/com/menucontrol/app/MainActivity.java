package com.menucontrol.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.menucontrol.app.adapters.DishAdapter;
import com.menucontrol.app.dao.MenuDAO;
import com.menucontrol.app.models.Dish;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements DishAdapter.OnDishCountChangeListener {
    private RecyclerView dishesRecyclerView;
    private DishAdapter dishAdapter;
    private TextView dateText;
    private TextView totalRevenueValue;
    private Button manageMenuButton;
    private Button historyButton;
    private Button statisticsButton;
    private Button resetButton;
    
    private MenuDAO menuDAO;
    private List<Dish> dishes;
    private SimpleDateFormat dateFormat;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        initializeData();
        setupRecyclerView();
        setupClickListeners();
        updateDateDisplay();
        loadDishes();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        loadDishes(); // Refresh data when returning from other activities
    }
    
    private void initializeViews() {
        dishesRecyclerView = findViewById(R.id.dishesRecyclerView);
        dateText = findViewById(R.id.dateText);
        totalRevenueValue = findViewById(R.id.totalRevenueValue);
        manageMenuButton = findViewById(R.id.manageMenuButton);
        historyButton = findViewById(R.id.historyButton);
        statisticsButton = findViewById(R.id.statisticsButton);
        resetButton = findViewById(R.id.resetButton);
    }
    
    private void initializeData() {
        menuDAO = new MenuDAO(this);
        dateFormat = new SimpleDateFormat("EEEE, d 'de' MMMM yyyy", new Locale("es", "ES"));
    }
    
    private void setupRecyclerView() {
        dishesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupClickListeners() {
        manageMenuButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ManageMenuActivity.class);
            startActivity(intent);
        });
        
        historyButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryActivity.class);
            startActivity(intent);
        });
        
        statisticsButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, StatisticsActivity.class);
            startActivity(intent);
        });
        
        resetButton.setOnClickListener(v -> showResetConfirmDialog());
    }
    
    private void updateDateDisplay() {
        String currentDate = dateFormat.format(new Date());
        dateText.setText(currentDate);
    }
    
    private void loadDishes() {
        dishes = menuDAO.getAllActiveDishes();
        
        if (dishAdapter == null) {
            dishAdapter = new DishAdapter(dishes, this);
            dishesRecyclerView.setAdapter(dishAdapter);
        } else {
            dishAdapter.updateDishes(dishes);
        }
        
        updateTotalRevenue();
    }
    
    private void updateTotalRevenue() {
        double totalRevenue = 0.0;
        for (Dish dish : dishes) {
            totalRevenue += dish.getDailyRevenue();
        }
        totalRevenueValue.setText(String.format(Locale.getDefault(), "$%.2f", totalRevenue));
    }
    
    @Override
    public void onIncrement(Dish dish) {
        if (menuDAO.incrementDailyCount(dish.getId())) {
            dish.setDailyCount(dish.getDailyCount() + 1);
            dishAdapter.notifyDataSetChanged();
            updateTotalRevenue();
        } else {
            Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onDecrement(Dish dish) {
        if (dish.getDailyCount() > 0) {
            if (menuDAO.decrementDailyCount(dish.getId())) {
                dish.setDailyCount(dish.getDailyCount() - 1);
                dishAdapter.notifyDataSetChanged();
                updateTotalRevenue();
            } else {
                Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void showResetConfirmDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.reset_day)
                .setMessage(R.string.confirm_reset)
                .setPositiveButton(R.string.reset_day, (dialog, which) -> resetDailyCounts())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
    
    private void resetDailyCounts() {
        SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String today = dbDateFormat.format(new Date());
        
        // Save current day to history before resetting
        menuDAO.saveDayToHistory(today);
        
        // Reset daily counts
        if (menuDAO.resetDailyCounts(today)) {
            loadDishes();
            Toast.makeText(this, "Día reiniciado exitosamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
        }
    }
}