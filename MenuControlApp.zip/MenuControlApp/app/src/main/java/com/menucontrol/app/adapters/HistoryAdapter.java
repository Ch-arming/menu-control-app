package com.menucontrol.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.menucontrol.app.R;
import com.menucontrol.app.models.DailyCount;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {
    private List<DailyCount> historyItems;
    private SimpleDateFormat inputFormat;
    private SimpleDateFormat outputFormat;
    
    public HistoryAdapter(List<DailyCount> historyItems) {
        this.historyItems = historyItems;
        this.inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        this.outputFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    }
    
    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new HistoryViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        DailyCount item = historyItems.get(position);
        holder.bind(item);
    }
    
    @Override
    public int getItemCount() {
        return historyItems.size();
    }
    
    public void updateHistory(List<DailyCount> newHistory) {
        this.historyItems = newHistory;
        notifyDataSetChanged();
    }
    
    class HistoryViewHolder extends RecyclerView.ViewHolder {
        private TextView dateText;
        private TextView dishNameText;
        private TextView categoryText;
        private TextView quantityText;
        private TextView revenueText;
        
        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            dishNameText = itemView.findViewById(R.id.dishNameText);
            categoryText = itemView.findViewById(R.id.categoryText);
            quantityText = itemView.findViewById(R.id.quantityText);
            revenueText = itemView.findViewById(R.id.revenueText);
        }
        
        public void bind(DailyCount item) {
            // Format date
            try {
                Date date = inputFormat.parse(item.getDate());
                dateText.setText(outputFormat.format(date));
            } catch (ParseException e) {
                dateText.setText(item.getDate());
            }
            
            dishNameText.setText(item.getDishName());
            // Extract category from dish name or use a default
            categoryText.setText("Plato");
            
            quantityText.setText(String.format(Locale.getDefault(), "%d unidades", item.getQuantity()));
            revenueText.setText(String.format(Locale.getDefault(), "$%.2f", item.getRevenue()));
        }
    }
}