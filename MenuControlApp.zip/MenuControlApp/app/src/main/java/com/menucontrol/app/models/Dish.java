package com.menucontrol.app.models;

import java.io.Serializable;

public class Dish implements Serializable {
    private int id;
    private String name;
    private String category;
    private double price;
    private boolean active;
    private int dailyCount;
    
    public Dish() {}
    
    public Dish(String name, String category, double price) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.active = true;
        this.dailyCount = 0;
    }
    
    public Dish(int id, String name, String category, double price, boolean active) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.active = active;
        this.dailyCount = 0;
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public boolean isActive() {
        return active;
    }
    
    public void setActive(boolean active) {
        this.active = active;
    }
    
    public int getDailyCount() {
        return dailyCount;
    }
    
    public void setDailyCount(int dailyCount) {
        this.dailyCount = dailyCount;
    }
    
    public double getDailyRevenue() {
        return dailyCount * price;
    }
    
    @Override
    public String toString() {
        return name + " (" + category + ") - $" + String.format("%.2f", price);
    }
}