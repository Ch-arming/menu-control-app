package com.menucontrol.app.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.menucontrol.app.database.DatabaseHelper;
import com.menucontrol.app.models.Dish;
import com.menucontrol.app.models.DailyCount;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MenuDAO {
    private DatabaseHelper dbHelper;
    private SimpleDateFormat dateFormat;
    
    public MenuDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    }
    
    // Dish operations
    public long addDish(Dish dish) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.DISH_NAME, dish.getName());
        values.put(DatabaseHelper.DISH_CATEGORY, dish.getCategory());
        values.put(DatabaseHelper.DISH_PRICE, dish.getPrice());
        values.put(DatabaseHelper.DISH_ACTIVE, dish.isActive() ? 1 : 0);
        
        long id = db.insert(DatabaseHelper.TABLE_DISHES, null, values);
        db.close();
        return id;
    }
    
    public boolean updateDish(Dish dish) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.DISH_NAME, dish.getName());
        values.put(DatabaseHelper.DISH_CATEGORY, dish.getCategory());
        values.put(DatabaseHelper.DISH_PRICE, dish.getPrice());
        values.put(DatabaseHelper.DISH_ACTIVE, dish.isActive() ? 1 : 0);
        
        int result = db.update(DatabaseHelper.TABLE_DISHES, values, 
                              DatabaseHelper.DISH_ID + " = ?", 
                              new String[]{String.valueOf(dish.getId())});
        db.close();
        return result > 0;
    }
    
    public boolean deleteDish(int dishId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        // Instead of deleting, mark as inactive
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.DISH_ACTIVE, 0);
        
        int result = db.update(DatabaseHelper.TABLE_DISHES, values, 
                              DatabaseHelper.DISH_ID + " = ?", 
                              new String[]{String.valueOf(dishId)});
        db.close();
        return result > 0;
    }
    
    public List<Dish> getAllActiveDishes() {
        List<Dish> dishes = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_DISHES + 
                      " WHERE " + DatabaseHelper.DISH_ACTIVE + " = 1" +
                      " ORDER BY " + DatabaseHelper.DISH_CATEGORY + ", " + DatabaseHelper.DISH_NAME;
        
        Cursor cursor = db.rawQuery(query, null);
        
        if (cursor.moveToFirst()) {
            do {
                Dish dish = new Dish();
                dish.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_ID)));
                dish.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_NAME)));
                dish.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_CATEGORY)));
                dish.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_PRICE)));
                dish.setActive(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_ACTIVE)) == 1);
                
                // Get today's count for this dish
                String today = dateFormat.format(new Date());
                dish.setDailyCount(getDailyCount(dish.getId(), today));
                
                dishes.add(dish);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return dishes;
    }
    
    public Dish getDishById(int dishId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_DISHES, null,
                                DatabaseHelper.DISH_ID + " = ?",
                                new String[]{String.valueOf(dishId)},
                                null, null, null);
        
        Dish dish = null;
        if (cursor.moveToFirst()) {
            dish = new Dish();
            dish.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_ID)));
            dish.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_NAME)));
            dish.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_CATEGORY)));
            dish.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_PRICE)));
            dish.setActive(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_ACTIVE)) == 1);
        }
        
        cursor.close();
        db.close();
        return dish;
    }
    
    // Daily count operations
    public int getDailyCount(int dishId, String date) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_DAILY_COUNTS, 
                                new String[]{DatabaseHelper.COUNT_QUANTITY},
                                DatabaseHelper.COUNT_DISH_ID + " = ? AND " + DatabaseHelper.COUNT_DATE + " = ?",
                                new String[]{String.valueOf(dishId), date},
                                null, null, null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COUNT_QUANTITY));
        }
        
        cursor.close();
        db.close();
        return count;
    }
    
    public boolean updateDailyCount(int dishId, String date, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        // Check if record exists
        Cursor cursor = db.query(DatabaseHelper.TABLE_DAILY_COUNTS, 
                                new String[]{DatabaseHelper.COUNT_ID},
                                DatabaseHelper.COUNT_DISH_ID + " = ? AND " + DatabaseHelper.COUNT_DATE + " = ?",
                                new String[]{String.valueOf(dishId), date},
                                null, null, null);
        
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COUNT_DISH_ID, dishId);
        values.put(DatabaseHelper.COUNT_DATE, date);
        values.put(DatabaseHelper.COUNT_QUANTITY, quantity);
        
        long result;
        if (cursor.moveToFirst()) {
            // Update existing record
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COUNT_ID));
            result = db.update(DatabaseHelper.TABLE_DAILY_COUNTS, values,
                              DatabaseHelper.COUNT_ID + " = ?",
                              new String[]{String.valueOf(id)});
        } else {
            // Insert new record
            result = db.insert(DatabaseHelper.TABLE_DAILY_COUNTS, null, values);
        }
        
        cursor.close();
        db.close();
        return result > 0;
    }
    
    public boolean incrementDailyCount(int dishId) {
        String today = dateFormat.format(new Date());
        int currentCount = getDailyCount(dishId, today);
        return updateDailyCount(dishId, today, currentCount + 1);
    }
    
    public boolean decrementDailyCount(int dishId) {
        String today = dateFormat.format(new Date());
        int currentCount = getDailyCount(dishId, today);
        if (currentCount > 0) {
            return updateDailyCount(dishId, today, currentCount - 1);
        }
        return false;
    }
    
    public boolean resetDailyCounts(String date) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int result = db.delete(DatabaseHelper.TABLE_DAILY_COUNTS,
                              DatabaseHelper.COUNT_DATE + " = ?",
                              new String[]{date});
        db.close();
        return result >= 0;
    }
    
    // History operations
    public boolean saveDayToHistory(String date) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        // Delete existing history for this date
        db.delete(DatabaseHelper.TABLE_HISTORY,
                 DatabaseHelper.HISTORY_DATE + " = ?",
                 new String[]{date});
        
        // Get all daily counts for the date
        String query = "SELECT dc." + DatabaseHelper.COUNT_DISH_ID + ", " +
                      "dc." + DatabaseHelper.COUNT_QUANTITY + ", " +
                      "d." + DatabaseHelper.DISH_PRICE + " " +
                      "FROM " + DatabaseHelper.TABLE_DAILY_COUNTS + " dc " +
                      "JOIN " + DatabaseHelper.TABLE_DISHES + " d ON dc." + DatabaseHelper.COUNT_DISH_ID + " = d." + DatabaseHelper.DISH_ID + " " +
                      "WHERE dc." + DatabaseHelper.COUNT_DATE + " = ?";
        
        Cursor cursor = db.rawQuery(query, new String[]{date});
        
        boolean success = true;
        if (cursor.moveToFirst()) {
            do {
                int dishId = cursor.getInt(0);
                int quantity = cursor.getInt(1);
                double price = cursor.getDouble(2);
                double revenue = quantity * price;
                
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.HISTORY_DISH_ID, dishId);
                values.put(DatabaseHelper.HISTORY_DATE, date);
                values.put(DatabaseHelper.HISTORY_QUANTITY, quantity);
                values.put(DatabaseHelper.HISTORY_REVENUE, revenue);
                
                long result = db.insert(DatabaseHelper.TABLE_HISTORY, null, values);
                if (result == -1) {
                    success = false;
                }
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return success;
    }
    
    public List<DailyCount> getHistoryByDateRange(String startDate, String endDate) {
        List<DailyCount> history = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        String query = "SELECT h.*, d." + DatabaseHelper.DISH_NAME + ", d." + DatabaseHelper.DISH_PRICE + " " +
                      "FROM " + DatabaseHelper.TABLE_HISTORY + " h " +
                      "JOIN " + DatabaseHelper.TABLE_DISHES + " d ON h." + DatabaseHelper.HISTORY_DISH_ID + " = d." + DatabaseHelper.DISH_ID + " " +
                      "WHERE h." + DatabaseHelper.HISTORY_DATE + " BETWEEN ? AND ? " +
                      "ORDER BY h." + DatabaseHelper.HISTORY_DATE + " DESC, d." + DatabaseHelper.DISH_NAME;
        
        Cursor cursor = db.rawQuery(query, new String[]{startDate, endDate});
        
        if (cursor.moveToFirst()) {
            do {
                DailyCount count = new DailyCount();
                count.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.HISTORY_ID)));
                count.setDishId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.HISTORY_DISH_ID)));
                count.setDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.HISTORY_DATE)));
                count.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.HISTORY_QUANTITY)));
                count.setDishName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_NAME)));
                count.setDishPrice(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.DISH_PRICE)));
                
                history.add(count);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return history;
    }
    
    public double getTotalRevenueForDate(String date) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(" + DatabaseHelper.HISTORY_REVENUE + ") FROM " + DatabaseHelper.TABLE_HISTORY + " WHERE " + DatabaseHelper.HISTORY_DATE + " = ?", new String[]{date});
        
        double total = 0.0;
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0);
        }
        
        cursor.close();
        db.close();
        return total;
    }
}