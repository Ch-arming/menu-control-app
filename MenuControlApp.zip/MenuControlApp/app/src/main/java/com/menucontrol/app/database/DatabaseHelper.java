package com.menucontrol.app.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "menu_control.db";
    private static final int DATABASE_VERSION = 1;
    
    // Tables
    public static final String TABLE_DISHES = "dishes";
    public static final String TABLE_DAILY_COUNTS = "daily_counts";
    public static final String TABLE_HISTORY = "history";
    
    // Dishes table columns
    public static final String DISH_ID = "id";
    public static final String DISH_NAME = "name";
    public static final String DISH_CATEGORY = "category";
    public static final String DISH_PRICE = "price";
    public static final String DISH_ACTIVE = "active";
    
    // Daily counts table columns
    public static final String COUNT_ID = "id";
    public static final String COUNT_DISH_ID = "dish_id";
    public static final String COUNT_DATE = "date";
    public static final String COUNT_QUANTITY = "quantity";
    
    // History table columns
    public static final String HISTORY_ID = "id";
    public static final String HISTORY_DISH_ID = "dish_id";
    public static final String HISTORY_DATE = "date";
    public static final String HISTORY_QUANTITY = "quantity";
    public static final String HISTORY_REVENUE = "revenue";
    
    // Create tables SQL
    private static final String CREATE_DISHES_TABLE = 
        "CREATE TABLE " + TABLE_DISHES + "(" +
        DISH_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        DISH_NAME + " TEXT NOT NULL," +
        DISH_CATEGORY + " TEXT NOT NULL," +
        DISH_PRICE + " REAL DEFAULT 0," +
        DISH_ACTIVE + " INTEGER DEFAULT 1" +
        ")";
    
    private static final String CREATE_DAILY_COUNTS_TABLE = 
        "CREATE TABLE " + TABLE_DAILY_COUNTS + "(" +
        COUNT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        COUNT_DISH_ID + " INTEGER," +
        COUNT_DATE + " TEXT NOT NULL," +
        COUNT_QUANTITY + " INTEGER DEFAULT 0," +
        "FOREIGN KEY(" + COUNT_DISH_ID + ") REFERENCES " + TABLE_DISHES + "(" + DISH_ID + ")" +
        ")";
    
    private static final String CREATE_HISTORY_TABLE = 
        "CREATE TABLE " + TABLE_HISTORY + "(" +
        HISTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
        HISTORY_DISH_ID + " INTEGER," +
        HISTORY_DATE + " TEXT NOT NULL," +
        HISTORY_QUANTITY + " INTEGER DEFAULT 0," +
        HISTORY_REVENUE + " REAL DEFAULT 0," +
        "FOREIGN KEY(" + HISTORY_DISH_ID + ") REFERENCES " + TABLE_DISHES + "(" + DISH_ID + ")" +
        ")";
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_DISHES_TABLE);
        db.execSQL(CREATE_DAILY_COUNTS_TABLE);
        db.execSQL(CREATE_HISTORY_TABLE);
        
        // Insert default dishes
        insertDefaultDishes(db);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_COUNTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DISHES);
        onCreate(db);
    }
    
    private void insertDefaultDishes(SQLiteDatabase db) {
        // Sample dishes
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Ensalada César', 'Entradas', 12.50)");
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Pollo a la Plancha', 'Platos Principales', 25.00)");
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Pasta Carbonara', 'Platos Principales', 18.50)");
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Tiramisu', 'Postres', 8.00)");
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Agua Mineral', 'Bebidas', 3.50)");
        db.execSQL("INSERT INTO " + TABLE_DISHES + "(" + DISH_NAME + ", " + DISH_CATEGORY + ", " + DISH_PRICE + ") VALUES ('Café Americano', 'Bebidas', 4.00)");
    }
}