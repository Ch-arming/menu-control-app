package com.menucontrol.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.menucontrol.app.adapters.HistoryAdapter;
import com.menucontrol.app.dao.MenuDAO;
import com.menucontrol.app.models.DailyCount;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {
    private RecyclerView historyRecyclerView;
    private HistoryAdapter historyAdapter;
    private Button startDateButton;
    private Button endDateButton;
    private Button exportButton;
    private TextView totalQuantityText;
    private TextView totalRevenueText;
    private LinearLayout emptyStateLayout;
    
    private MenuDAO menuDAO;
    private List<DailyCount> historyItems;
    private SimpleDateFormat dateFormat;
    private Calendar startDate;
    private Calendar endDate;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        
        initializeViews();
        initializeData();
        setupRecyclerView();
        setupClickListeners();
        setDefaultDateRange();
        loadHistory();
    }
    
    private void initializeViews() {
        historyRecyclerView = findViewById(R.id.historyRecyclerView);
        startDateButton = findViewById(R.id.startDateButton);
        endDateButton = findViewById(R.id.endDateButton);
        exportButton = findViewById(R.id.exportButton);
        totalQuantityText = findViewById(R.id.totalQuantityText);
        totalRevenueText = findViewById(R.id.totalRevenueText);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
    }
    
    private void initializeData() {
        menuDAO = new MenuDAO(this);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        startDate = Calendar.getInstance();
        endDate = Calendar.getInstance();
    }
    
    private void setupRecyclerView() {
        historyRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupClickListeners() {
        startDateButton.setOnClickListener(v -> showDatePicker(true));
        endDateButton.setOnClickListener(v -> showDatePicker(false));
        exportButton.setOnClickListener(v -> exportData());
    }
    
    private void setDefaultDateRange() {
        // Set end date to today
        endDate.setTime(new Date());
        
        // Set start date to 30 days ago
        startDate.setTime(new Date());
        startDate.add(Calendar.DAY_OF_MONTH, -30);
        
        updateDateButtons();
    }
    
    private void updateDateButtons() {
        SimpleDateFormat buttonFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        startDateButton.setText(buttonFormat.format(startDate.getTime()));
        endDateButton.setText(buttonFormat.format(endDate.getTime()));
    }
    
    private void showDatePicker(boolean isStartDate) {
        Calendar calendar = isStartDate ? startDate : endDate;
        
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    updateDateButtons();
                    loadHistory();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        
        datePickerDialog.show();
    }
    
    private void loadHistory() {
        String startDateStr = dateFormat.format(startDate.getTime());
        String endDateStr = dateFormat.format(endDate.getTime());
        
        historyItems = menuDAO.getHistoryByDateRange(startDateStr, endDateStr);
        
        if (historyItems.isEmpty()) {
            emptyStateLayout.setVisibility(LinearLayout.VISIBLE);
            historyRecyclerView.setVisibility(RecyclerView.GONE);
        } else {
            emptyStateLayout.setVisibility(LinearLayout.GONE);
            historyRecyclerView.setVisibility(RecyclerView.VISIBLE);
            
            if (historyAdapter == null) {
                historyAdapter = new HistoryAdapter(historyItems);
                historyRecyclerView.setAdapter(historyAdapter);
            } else {
                historyAdapter.updateHistory(historyItems);
            }
        }
        
        updateSummary();
    }
    
    private void updateSummary() {
        int totalQuantity = 0;
        double totalRevenue = 0.0;
        
        for (DailyCount item : historyItems) {
            totalQuantity += item.getQuantity();
            totalRevenue += item.getRevenue();
        }
        
        totalQuantityText.setText(String.valueOf(totalQuantity));
        totalRevenueText.setText(String.format(Locale.getDefault(), "$%.2f", totalRevenue));
    }
    
    private void exportData() {
        if (historyItems.isEmpty()) {
            Toast.makeText(this, "No hay datos para exportar", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File file = new File(downloadsDir, "menu_control_history.csv");
            
            FileWriter writer = new FileWriter(file);
            
            // Write CSV header
            writer.append("Fecha,Plato,Cantidad,Precio Unitario,Total\n");
            
            // Write data
            for (DailyCount item : historyItems) {
                writer.append(String.format(Locale.getDefault(),
                        "%s,%s,%d,%.2f,%.2f\n",
                        item.getDate(),
                        item.getDishName(),
                        item.getQuantity(),
                        item.getDishPrice(),
                        item.getRevenue()));
            }
            
            writer.close();
            
            Toast.makeText(this, R.string.export_success, Toast.LENGTH_LONG).show();
            
            // Open the file with default app
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.fromFile(file), "text/csv");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
            
        } catch (IOException e) {
            Toast.makeText(this, R.string.export_error, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}