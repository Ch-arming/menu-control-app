package com.menucontrol.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.menucontrol.app.adapters.MenuManageAdapter;
import com.menucontrol.app.dao.MenuDAO;
import com.menucontrol.app.models.Dish;

import java.util.List;

public class ManageMenuActivity extends AppCompatActivity implements MenuManageAdapter.OnMenuItemActionListener {
    private RecyclerView menuItemsRecyclerView;
    private MenuManageAdapter menuAdapter;
    private FloatingActionButton addDishButton;
    private LinearLayout emptyStateLayout;
    
    private MenuDAO menuDAO;
    private List<Dish> dishes;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_menu);
        
        initializeViews();
        initializeData();
        setupRecyclerView();
        setupClickListeners();
        loadDishes();
    }
    
    private void initializeViews() {
        menuItemsRecyclerView = findViewById(R.id.menuItemsRecyclerView);
        addDishButton = findViewById(R.id.addDishButton);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
    }
    
    private void initializeData() {
        menuDAO = new MenuDAO(this);
    }
    
    private void setupRecyclerView() {
        menuItemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupClickListeners() {
        addDishButton.setOnClickListener(v -> showAddDishDialog(null));
    }
    
    private void loadDishes() {
        dishes = menuDAO.getAllActiveDishes();
        
        if (dishes.isEmpty()) {
            emptyStateLayout.setVisibility(View.VISIBLE);
            menuItemsRecyclerView.setVisibility(View.GONE);
        } else {
            emptyStateLayout.setVisibility(View.GONE);
            menuItemsRecyclerView.setVisibility(View.VISIBLE);
            
            if (menuAdapter == null) {
                menuAdapter = new MenuManageAdapter(dishes, this);
                menuItemsRecyclerView.setAdapter(menuAdapter);
            } else {
                menuAdapter.updateDishes(dishes);
            }
        }
    }
    
    private void showAddDishDialog(Dish dishToEdit) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_dish, null);
        
        TextInputEditText dishNameEditText = dialogView.findViewById(R.id.dishNameEditText);
        AutoCompleteTextView categorySpinner = dialogView.findViewById(R.id.categorySpinner);
        TextInputEditText priceEditText = dialogView.findViewById(R.id.priceEditText);
        
        // Setup category spinner
        String[] categories = getResources().getStringArray(R.array.categories);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, categories);
        categorySpinner.setAdapter(adapter);
        
        // If editing, populate fields
        boolean isEditing = dishToEdit != null;
        if (isEditing) {
            dishNameEditText.setText(dishToEdit.getName());
            categorySpinner.setText(dishToEdit.getCategory(), false);
            priceEditText.setText(String.valueOf(dishToEdit.getPrice()));
        }
        
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();
        
        // Setup buttons
        dialogView.findViewById(R.id.cancelButton).setOnClickListener(v -> dialog.dismiss());
        
        dialogView.findViewById(R.id.saveButton).setOnClickListener(v -> {
            String name = dishNameEditText.getText().toString().trim();
            String category = categorySpinner.getText().toString().trim();
            String priceStr = priceEditText.getText().toString().trim();
            
            if (validateDishInput(name, category, priceStr)) {
                double price = Double.parseDouble(priceStr);
                
                if (isEditing) {
                    updateDish(dishToEdit, name, category, price);
                } else {
                    addNewDish(name, category, price);
                }
                
                dialog.dismiss();
                loadDishes();
            }
        });
        
        dialog.show();
    }
    
    private boolean validateDishInput(String name, String category, String priceStr) {
        if (name.isEmpty()) {
            Toast.makeText(this, "Ingrese el nombre del plato", Toast.LENGTH_SHORT).show();
            return false;
        }
        
        if (category.isEmpty()) {
            Toast.makeText(this, "Seleccione una categoría", Toast.LENGTH_SHORT).show();
            return false;
        }
        
        try {
            double price = Double.parseDouble(priceStr);
            if (price < 0) {
                Toast.makeText(this, "El precio debe ser positivo", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese un precio válido", Toast.LENGTH_SHORT).show();
            return false;
        }
        
        return true;
    }
    
    private void addNewDish(String name, String category, double price) {
        Dish newDish = new Dish(name, category, price);
        long result = menuDAO.addDish(newDish);
        
        if (result > 0) {
            Toast.makeText(this, R.string.success_saving, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
        }
    }
    
    private void updateDish(Dish dish, String name, String category, double price) {
        dish.setName(name);
        dish.setCategory(category);
        dish.setPrice(price);
        
        if (menuDAO.updateDish(dish)) {
            Toast.makeText(this, R.string.success_saving, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    public void onEdit(Dish dish) {
        showAddDishDialog(dish);
    }
    
    @Override
    public void onDelete(Dish dish) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete)
                .setMessage(R.string.confirm_delete)
                .setPositiveButton(R.string.delete, (dialog, which) -> deleteDish(dish))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
    
    private void deleteDish(Dish dish) {
        if (menuDAO.deleteDish(dish.getId())) {
            Toast.makeText(this, "Plato eliminado exitosamente", Toast.LENGTH_SHORT).show();
            loadDishes();
        } else {
            Toast.makeText(this, R.string.error_saving, Toast.LENGTH_SHORT).show();
        }
    }
}