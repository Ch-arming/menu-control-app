package com.menucontrol.app.adapters;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.menucontrol.app.R;
import com.menucontrol.app.models.Dish;

import java.util.List;
import java.util.Locale;

public class MenuManageAdapter extends RecyclerView.Adapter<MenuManageAdapter.MenuManageViewHolder> {
    private List<Dish> dishes;
    private OnMenuItemActionListener listener;
    
    public interface OnMenuItemActionListener {
        void onEdit(Dish dish);
        void onDelete(Dish dish);
    }
    
    public MenuManageAdapter(List<Dish> dishes, OnMenuItemActionListener listener) {
        this.dishes = dishes;
        this.listener = listener;
    }
    
    @NonNull
    @Override
    public MenuManageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_menu_manage, parent, false);
        return new MenuManageViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull MenuManageViewHolder holder, int position) {
        Dish dish = dishes.get(position);
        holder.bind(dish);
    }
    
    @Override
    public int getItemCount() {
        return dishes.size();
    }
    
    public void updateDishes(List<Dish> newDishes) {
        this.dishes = newDishes;
        notifyDataSetChanged();
    }
    
    class MenuManageViewHolder extends RecyclerView.ViewHolder {
        private TextView dishNameText;
        private TextView categoryText;
        private TextView priceText;
        private MaterialButton editButton;
        private MaterialButton deleteButton;
        private View categoryIndicator;
        
        public MenuManageViewHolder(@NonNull View itemView) {
            super(itemView);
            dishNameText = itemView.findViewById(R.id.dishNameText);
            categoryText = itemView.findViewById(R.id.categoryText);
            priceText = itemView.findViewById(R.id.priceText);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            categoryIndicator = itemView.findViewById(R.id.categoryIndicator);
        }
        
        public void bind(Dish dish) {
            dishNameText.setText(dish.getName());
            categoryText.setText(dish.getCategory());
            priceText.setText(String.format(Locale.getDefault(), "$%.2f", dish.getPrice()));
            
            // Set category indicator color
            int categoryColor = getCategoryColor(dish.getCategory());
            categoryIndicator.setBackgroundTintList(ColorStateList.valueOf(categoryColor));
            
            // Set click listeners
            editButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onEdit(dish);
                }
            });
            
            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDelete(dish);
                }
            });
        }
        
        private int getCategoryColor(String category) {
            switch (category) {
                case "Entradas":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_entradas);
                case "Platos Principales":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_principales);
                case "Postres":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_postres);
                case "Bebidas":
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_bebidas);
                default:
                    return ContextCompat.getColor(itemView.getContext(), R.color.category_otros);
            }
        }
    }
}