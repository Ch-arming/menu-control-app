# Control de Menú - Aplicación Android

## Descripción
Aplicación Android para control diario de platos de menú con funcionalidades completas de gestión, conteo y análisis histórico.

## Características Principales

### 📱 Pantalla Principal
- Visualización de todos los platos del menú organizados por categorías
- Contadores interactivos (+/-) para cada plato
- Cálculo automático de ingresos diarios
- Fecha actual y total de ingresos del día
- Función de reinicio diario

### 🍽️ Gestión de Menú
- Agregar nuevos platos con nombre, categoría y precio
- Editar platos existentes
- Eliminar platos (marcado como inactivo)
- Categorías predefinidas: Entradas, Platos Principales, Postres, Bebidas, Otros
- Indicadores visuales por categoría

### 📊 Historial y Reportes
- Historial completo de ventas por rango de fechas
- Resumen de cantidades vendidas e ingresos
- Filtros de fecha personalizables
- Exportación de datos a CSV

### 📈 Estadísticas
- Gráfico circular de distribución de ingresos por plato
- Gráfico de barras de ventas diarias
- Estadísticas resumidas: total vendido, ingresos, plato más popular
- Análisis de los últimos 30 días

## Tecnologías Utilizadas

- **Android SDK**: Desarrollo nativo para Android
- **SQLite**: Base de datos local para almacenamiento offline
- **Material Design 3**: Interfaz moderna y consistente
- **MPAndroidChart**: Gráficos y visualización de datos
- **RecyclerView**: Listas eficientes y adaptables

## Estructura del Proyecto

```
MenuControlApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/menucontrol/app/
│   │   │   ├── MainActivity.java           # Pantalla principal
│   │   │   ├── ManageMenuActivity.java     # Gestión de menú
│   │   │   ├── HistoryActivity.java        # Historial
│   │   │   ├── StatisticsActivity.java     # Estadísticas
│   │   │   ├── adapters/                   # Adaptadores RecyclerView
│   │   │   ├── database/                   # Helper de base de datos
│   │   │   ├── dao/                        # Acceso a datos
│   │   │   └── models/                     # Modelos de datos
│   │   ├── res/
│   │   │   ├── layout/                     # Layouts XML
│   │   │   ├── values/                     # Recursos (strings, colors, etc.)
│   │   │   └── drawable/                   # Iconos y recursos gráficos
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── README.md
```

## Base de Datos

### Tablas
1. **dishes**: Información de platos (id, nombre, categoría, precio, activo)
2. **daily_counts**: Conteos diarios (id, dish_id, fecha, cantidad)
3. **history**: Historial de ventas (id, dish_id, fecha, cantidad, ingresos)

## Instalación y Compilación

### Requisitos
- Android Studio Arctic Fox o superior
- Android SDK 21+ (Android 5.0+)
- Gradle 8.1+

### Pasos para Compilar

1. **Clonar/Descargar el proyecto**
   ```bash
   # Si tienes el proyecto en un repositorio
   git clone [URL_DEL_REPOSITORIO]
   ```

2. **Abrir en Android Studio**
   - Abrir Android Studio
   - File → Open
   - Seleccionar la carpeta `MenuControlApp`

3. **Sincronizar dependencias**
   - Android Studio automáticamente sincronizará las dependencias
   - Si no, ir a File → Sync Project with Gradle Files

4. **Compilar APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - El APK se generará en `app/build/outputs/apk/debug/`

### Compilación desde línea de comandos
```bash
cd MenuControlApp
./gradlew assembleDebug
```

## Uso de la Aplicación

### Primera vez
1. La aplicación incluye platos de ejemplo
2. Puedes agregar, editar o eliminar platos desde "Gestionar Menú"
3. Usa los botones +/- para registrar ventas diarias

### Flujo diario
1. Abre la app y registra las ventas usando los contadores
2. Visualiza el total de ingresos del día en tiempo real
3. Al final del día, usa "Reiniciar día" para guardar en historial

### Análisis
- Accede al historial para ver ventas pasadas
- Exporta datos en formato CSV
- Revisa estadísticas y gráficos para análisis de tendencias

## Funcionalidades Destacadas

- **Almacenamiento Offline**: Funciona sin conexión a internet
- **Interfaz Intuitiva**: Diseño Material Design 3
- **Exportación de Datos**: CSV para análisis externos
- **Gráficos Interactivos**: Visualización clara de datos
- **Historial Completo**: Nunca pierdas información de ventas
- **Categorización**: Organización clara del menú

## Soporte y Contacto

Para soporte técnico o consultas sobre la aplicación, contacta al desarrollador.

---

**Desarrollado por**: MiniMax Agent  
**Versión**: 1.0  
**Compatibilidad**: Android 5.0+ (API 21+)