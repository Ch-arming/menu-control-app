# 🚀 Guía Completa: Compilación desde GitHub

## Método 1: GitHub Actions (Automático) - RECOMENDADO

### Paso 1: Subir a GitHub
1. Crea un repositorio público en GitHub
2. Sube todos los archivos del proyecto
3. ¡La compilación será automática!

### Paso 2: Descargar APK
1. Ve a la pestaña "Actions" en tu repositorio
2. Click en el último "workflow run" exitoso
3. Descarga el artifact "menu-control-debug-apk"
4. ¡Ya tienes tu APK!

## Método 2: GitHub Codespaces

### Paso 1: Abrir Codespace
1. En tu repositorio, click "Code" → "Codespaces" → "Create codespace"
2. Espera a que se inicie el entorno

### Paso 2: Compilar
```bash
# En la terminal de Codespaces:
chmod +x gradlew
./gradlew assembleDebug
```

### Paso 3: Descargar APK
1. El APK estará en: `app/build/outputs/apk/debug/app-debug.apk`
2. Click derecho → Download

## Método 3: Servicios Online Alternativos

### AppBeta (online-android-compiler.com)
1. Sube el proyecto como ZIP
2. Espera la compilación automática
3. Descarga el APK generado

### Replit
1. Importa desde GitHub
2. Configura el entorno Android
3. Ejecuta la compilación

## ⚡ Solución de Problemas

### Error de permisos:
```bash
chmod +x gradlew
```

### Error de Java:
- Asegúrate de usar Java 17
- GitHub Actions ya tiene esto configurado

### Error de Gradle:
- El proyecto incluye Gradle Wrapper
- Usa `./gradlew` en lugar de `gradle`

## 📱 Instalación del APK

1. **Transferir a tu móvil**
   - USB, email, Google Drive, etc.

2. **Habilitar instalación de fuentes desconocidas**
   - Configuración → Seguridad → Fuentes desconocidas

3. **Instalar**
   - Toca el archivo APK
   - Confirma la instalación

¡Listo! Tu aplicación "Control de Menú" estará instalada y funcionando.
